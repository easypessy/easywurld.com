Draft starter slides for human review. Upload the five PNGs in order. Confirm price, offer fulfilment and platform crop before publishing. No synthetic presenter is used in these graphics.
