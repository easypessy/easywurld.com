# Tell me what you sell, in one sentence.

**Saturday 5 Dec · 20:00 Facebook, weekly LinkedIn · Facebook 20:00 → LinkedIn weekly · 1080×1350 carousel · 4 slides**

> Useful reply-bait — the soft sell. Example sector: restaurant. Illustrative figures — replace with your own market numbers before posting.

---

## LinkedIn

Tell me what you sell, in one sentence.

If it needs a paragraph, it is not clear yet. This is the cheapest diagnostic there is.

Who it is for, what it does, what changes after. Passes: “Cakes for Lagos offices that need 50 slices by 10am.”

Comment yours. I will rewrite the ones that miss.

If this is your business — a restaurant where the menu lives in an Instagram story that expires — message CLEAR on WhatsApp and I will send back the first thing I would change. No pitch.

#LagosFood #NaijaEats #Easywurld #LagosBusiness #SmallBusinessNigeria

---

## Instagram

Tell me what you sell, in one sentence. 🧡

If it needs a paragraph, it is not clear yet.
This is the cheapest diagnostic there is.

Who it is for, what it does, what changes after.
Passes: “Cakes for Lagos offices that need 50 slices by 10am.”

Comment yours.
I will rewrite the ones that miss.

Save this if it is you.

#LagosFood #NaijaEats #Easywurld #LagosBusiness #SmallBusinessNigeria #MarketingClarity #NaijaBusiness

---

## TikTok / Reels

Hook on screen: “Tell me what you sell, in one sentence.”

Beats:
0–3s — If it needs a paragraph, it is not clear yet..
3–10s — This is the cheapest diagnostic there is.
10–16s — Who it is for, what it does, what changes after.. Passes: “Cakes for Lagos offices that need 50 slices by 10am.”
16–20s — Comment yours.

Text on screen: “Comment yours.”

---

## WhatsApp status / broadcast

Tell me what you sell, in one sentence.

If it needs a paragraph, it is not clear yet. Who it is for, what it does, what changes after.

Comment yours.
I will rewrite the ones that miss.

Message CLEAR if you want the checklist.

---

## Hashtags (Instagram — use 8, drop the rest)

#LagosFood #NaijaEats #Easywurld #LagosBusiness #SmallBusinessNigeria #MarketingClarity #NaijaBusiness

---

## Slide copy (for reference / edits)

1. **Tell me what you sell, in one sentence.**
2. **If it needs a paragraph, it is not clear yet.** — This is the cheapest diagnostic there is.
3. **Who it is for, what it does, what changes after.** — Passes: “Cakes for Lagos offices that need 50 slices by 10am.”
4. **Comment yours.** — I will rewrite the ones that miss. *Message CLEAR · 0905 069 0837*
